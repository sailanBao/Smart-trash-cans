#include <REGX52.H>

//舵机
sbit Sg90_com = P1^0;
unsigned char count,compare,compare_back;

/**
  * @brief 定时器2初始化函数，舵机PWM控制
  * @param 无
  * @retval无
  */
void Init_timer2(void)
{
	
	T2MOD = 0;		//初始化模式寄存器
	T2CON = 0;		//初始化控制寄存器
	TL2 = 0x33;		//设置定时初值
	TH2 = 0xFE;		//设置定时初值
	RCAP2L = 0x33;		//设置定时重载值
	RCAP2H = 0xFE;		//设置定时重载值
	TR2 = 1;		//定时器2开始计时
	ET2=1;			 //打开定时器2中断
	EA=1;		 	 //打开总中断
}

/**
  * @brief 舵机旋转至90度
  * @param 无
  * @retval无
  */
void Sg_close(void)
{
	compare = 3;
	if(compare_back!=compare)
	{
		count = 0;
	}
	compare_back=compare;
}

/**
  * @brief 舵机旋转至0度
  * @param 无
  * @retval无
  */
void Sg_open()
{
	compare = 1;
	count = 0;
	compare_back=compare;
}

//中断处理函数
void Timer2_Routine(void)  interrupt  5 
{
	TF2=0;		
	count++;
	//PWM控制
	if(count < compare)		//通过比较值控制高电平占据周期的时间，也就是占空比大小
	{
		Sg90_com = 1;
	}
	else
	{
		Sg90_com = 0;
	}
	if(count == 40)	//每一个0.5mscount都会++，加了40次就20ms，是舵机控制的一个周期
	{
		count = 0;
		Sg90_com = 1;
	}
}