#include <REGX52.H>

/**
  * @brief 500毫秒延时函数
  * @param  500毫秒
  * @retval无
  */
void Delay500ms(unsigned char xms)		//@11.0592MHz
{
	unsigned char i, j, k;
	while(xms--)
	{
		i = 4;
		j = 129;
		k = 119;
		do
		{
			do
			{
				while (--k);
			} while (--j);
		} while (--i);
	}
	
}