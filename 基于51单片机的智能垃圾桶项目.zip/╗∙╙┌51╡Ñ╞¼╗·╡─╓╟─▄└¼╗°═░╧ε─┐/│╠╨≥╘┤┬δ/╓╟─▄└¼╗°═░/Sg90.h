#ifndef __SG90_H__
#define __SG90_H__
void Init_timer2(void);
void Sg_close();
void Sg_open();
#endif