#ifndef __SENION_H__
#define __SENION_H__
void Timer0Init(void);
double ultrasonic();
#endif