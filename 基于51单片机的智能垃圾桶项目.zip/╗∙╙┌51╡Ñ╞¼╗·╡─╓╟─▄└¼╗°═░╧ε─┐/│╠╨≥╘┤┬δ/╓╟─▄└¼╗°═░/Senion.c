#include <REGX52.H>
void Delay11us()		//@11.0592MHz
{
	unsigned char i;

	i = 28;
	while (--i);
}

sbit Trig = P1^1;
sbit Echo = P1^2;

/**
  * @brief定时器0初始化，超声波用
  * @param无
  * @retval无
  */
void Timer0Init(void)		//@11.0592MHz
{
	TMOD &= 0x0F;		//设置定时器模式
	TMOD |= 0x01;		//设置定时器模式
	TL0 = 0;		//设置定时初值
	TH0 = 0;		//设置定时初值
	TF0 = 0;		//清除TF1标志
}


//起始信号
void Trig_Start()
{
	Trig = 0;
	Trig = 1;
	Delay11us();
	Trig = 0;
}

/**
  * @brief超声波测距
  * @param无
  * @retval返回测到的距离，单位cm
  */
double ultrasonic()
{
	double time;
	double distance;
	TH0 = 0;
	TL0 = 0;
	Trig_Start();
	while(Echo == 0);
	TR0 = 1;
	while(Echo == 1);
	TR0 = 0;
	time = (TH0*256+TL0)*1.085;
	distance = time*0.017;
	return distance;
}
