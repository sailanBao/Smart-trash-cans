#include <REGX52.H>
#include <INTRINS.H>
#include "Sg90.h"
#include "Senion.h"
#include "Delay.h"

typedef unsigned int u16;
typedef unsigned char u8;

//垃圾箱状态
#define rubbish_free    0
#define rubbish_full     1
u8 rubbish_state=0;

//强制开关
#define Button_default  0
#define Button_open   1
#define Button_close   2
u8 Button_flght=0;

//垃圾箱开关状态
#define rubbish_open   1
#define rubbish_close   0
u8 rubbish_lid=0;
u8 rubbish_copare=0;

////获取距离
u16 Senion_Distance=0;

//检测是否满载
sbit infrared=P2^5;
//led
sbit Led_red=P2^7;
sbit Led_green=P2^6;

//蜂鸣器
sbit Buzzer=P2^4;

//总开关
sbit Key_close=P2^3;
sbit Key_open=P2^2;


//按键处理
void Key_Process(void)
{
	if(Key_close==0)
	{
		Button_flght=Button_close;
	}
	if(Key_open==0)
	{
		Button_flght=Button_open;
	}
}

void Getstate_Process(void)
{
	if(infrared==1)
	{
		rubbish_state=rubbish_free;
	}
	else if(infrared==0)
	{
		rubbish_state=rubbish_full;
	}
}

void main()
{
	Timer0Init();
	Init_timer2();
	Led_red=0;
	Led_green=0;
	Sg_close();
	Delay500ms(2);
	while(1)
	{
		Key_Process();
		//默认智能状态
		if(Button_flght==Button_default)
		{
			Getstate_Process();
			if(rubbish_state==rubbish_free)
			{
				Senion_Distance=ultrasonic();
				//如果距离较近，打开垃圾桶
				if(Senion_Distance<10 && Senion_Distance!=0)
				{
					rubbish_lid=rubbish_open;
					if(rubbish_copare!=rubbish_lid)
					{
						Buzzer=0;
						Delay500ms(1);
						Buzzer=1;
					}
					rubbish_copare=rubbish_lid;
					Sg_open();
					Led_red=0;
					Led_green=1;
					Delay500ms(4);
				}
				//如果面前没有人，就关闭垃圾桶盖
				else
				{
					rubbish_lid=rubbish_close;
					if(rubbish_copare!=rubbish_lid)
					{
						Buzzer=0;
						Delay500ms(1);
						Buzzer=1;
					}
					rubbish_copare=rubbish_lid;
					Led_green=0;
					Led_red=1;
					Sg_close();
					Delay500ms(4);
				}
			}
			else if(rubbish_state==rubbish_full)
			{
				Buzzer=0;
				Sg_open();
				Led_red=0;
				Delay500ms(1);
				Led_red=1;
				Delay500ms(1);
				Buzzer=1;
			}
		}
		else if(Button_flght==Button_close)
		{
			Sg_close();
			Delay500ms(1);
		}
		else if(Button_flght==Button_open)
		{
			Sg_open();
			Delay500ms(1);
		}
	}
}




